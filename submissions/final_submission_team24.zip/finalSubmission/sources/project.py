config = {
    'filename': 'resources/mushrooms.csv',
    'label': 'class',
}

results = 'results/'
